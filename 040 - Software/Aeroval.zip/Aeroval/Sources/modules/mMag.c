/*
 * mMag.c
 *
 *  Created on: 7 août 2015
 *      Author: valentinpy
 */

#include "mMag.h"


