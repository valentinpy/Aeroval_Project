/*
 * mMPU.h
 *
 *  Created on: 7 août 2015
 *      Author: valentinpy
 */

#ifndef SOURCES_MMPU_H_
#define SOURCES_MMPU_H_

#include "../misc/def.h"
#include "../interfaces/iI2C.h"



#endif /* SOURCES_MMPU_H_ */
