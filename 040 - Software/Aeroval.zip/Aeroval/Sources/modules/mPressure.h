/*
 * mPressure.h
 *
 *  Created on: 7 août 2015
 *      Author: valentinpy
 */

#ifndef SOURCES_MPRESSURE_H_
#define SOURCES_MPRESSURE_H_

#include "../misc/def.h"
#include "../interfaces/iI2C.h"


#endif /* SOURCES_MPRESSURE_H_ */
