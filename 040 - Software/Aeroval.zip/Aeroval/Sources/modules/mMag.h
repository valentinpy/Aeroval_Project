/*
 * mMag.h
 *
 *  Created on: 7 août 2015
 *      Author: valentinpy
 */

#ifndef SOURCES_MMAG_H_
#define SOURCES_MMAG_H_

#include "../misc/def.h"
#include "../interfaces/iI2C.h"


#endif /* SOURCES_MMAG_H_ */
