/*
 * gAltitudeSensors.c
 *
 *  Created on: 11 août 2015
 *      Author: valentinpy
 */


#include "gAltitudeSensors.h"

//-----------------------------------
// Altitude measurement initialization
//-----------------------------------
void gAltitudeSensors_Setup()
{
	//TODO implement
}

//-----------------------------------
// Altitude measurement
//-----------------------------------
void gAltitudeSensors_Run()
{
	//TODO implement
}
