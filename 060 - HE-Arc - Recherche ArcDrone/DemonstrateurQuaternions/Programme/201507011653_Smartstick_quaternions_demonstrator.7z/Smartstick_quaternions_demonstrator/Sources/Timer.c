/*
 * Timer.c
 *
 *  Created on: Jun 30, 2015
 *      Author: matthieu.favrebul
 */

#include "Timer.h"
#include "FC321.h"

//--------------------------------------------------
// Timer blocant
//--------------------------------------------------
void Timer_LockedWait(WaitTimer_Enum aTimeToWait)
{
	uint32 aTempVar = 0;
	// Reset du compteur
	FC321_Reset();
	// Attente
	while(aTimeToWait > aTempVar)
	{
		FC321_GetTimeMS(&aTempVar);
	}
}
