/*
 * mRs232.h
 *
 *  Created on: Jun 30, 2015
 *      Author: matthieu.favrebul
 */

#ifndef MRS232_H_
#define MRS232_H_

//------------------------------------------------------------------
// Send a string
//------------------------------------------------------------------
void mRs232_SendString(char* aStrToSend);

//------------------------------------------------------------------
// Recieve a string
//------------------------------------------------------------------
void mRs232_RecieveString(char* aStrToRecieve, uint8_t aNbbytesToRecieve);

//------------------------------------------------------------------
// Clear the reception buffer
//------------------------------------------------------------------
void mRs232_ClearRxBuffer(void);

#endif /* MRS232_H_ */
