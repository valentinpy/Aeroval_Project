/*
 * AppUserInterface.h
 *
 *  Created on: Jun 27, 2015
 *      Author: matthieu.favrebul
 */

#ifndef APPUSERINTERFACE_H_
#define APPUSERINTERFACE_H_



#endif /* APPUSERINTERFACE_H_ */
