/*
 * BT_HC_0305.c
 *
 *  Created on: Jun 29, 2015
 *      Author: matthieu.favrebul
 */

#include <stdio.h>
#include "string.h"
#include "AT_Mode_BT_n.h"
#include "mRs232.h"
#include "FC321.h"
#include "AS1.h"
#include "Reset_BT_n.h"

//------------------------------------------------
// Initialisation du bluetooth avec les commandes AT
//------------------------------------------------
void BT_HC_0305_Setup(void)
{
	char aTempBuffer[50] = {0};
	uint32_t aTempVar = 0;
	
	// Clear du buffer de r�ception
	mRs232_ClearRxBuffer();
	// On set le baudrate de l'UART � 38400
	AS1_SetBaudRateMode(AS1_BM_38400BAUD);
	
	
	// Reset du module bluetooth
	Reset_BT_n_ClrVal(Reset_BT_n_DeviceData);
	// Set du mode AT commande
	AT_Mode_BT_n_SetVal(AT_Mode_BT_n_DeviceData);
	// Attente d'une seconde
	aTempVar = 0;
	FC321_Reset();
	while(1000 > aTempVar)
	{
		FC321_GetTimeMS(&aTempVar);
	}
	// On enl�ve le reset du bluetooth
	Reset_BT_n_SetVal(Reset_BT_n_DeviceData);
	
	// Attente d'une seconde
	aTempVar = 0;
	FC321_Reset();
	while(1000 > aTempVar)
	{
		FC321_GetTimeMS(&aTempVar);
	}
	
	// Reglage du bluetooth
	mRs232_SendString("AT+UART=38400,0,0\r\n");
	//mRs232_SendString("AT\r\n");
	// Attente d'une seconde pour la r�ponse
	aTempVar = 0;
	FC321_Reset();
	while(1000 > aTempVar)
	{
		FC321_GetTimeMS(&aTempVar);
	}
	// On va lire dans le buffer la r�ponse
	mRs232_RecieveString(aTempBuffer, 20);
	
	// Reset du module bluetooth
	Reset_BT_n_ClrVal(Reset_BT_n_DeviceData);
	// Set du mode communication
	AT_Mode_BT_n_ClrVal(AT_Mode_BT_n_DeviceData);
	// Attente d'une seconde pour la r�ponse
	aTempVar = 0;
	FC321_Reset();
	while(1000 > aTempVar)
	{
		FC321_GetTimeMS(&aTempVar);
	}
	// On enl�ve le reset du bluetooth
	Reset_BT_n_SetVal(Reset_BT_n_DeviceData);
	
	// On set le baudrate de l'UART � 460800
	AS1_SetBaudRateMode(AS1_BM_38400BAUD);
}
