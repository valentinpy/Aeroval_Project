/*
 * mRs232.c
 *
 *  Created on: Jun 30, 2015
 *      Author: matthieu.favrebul
 */

#include "AS1.h"
#include "BT_HC_0305.h"
#include "string.h"
#include "mRs232.h"


//------------------------------------------------------------------
// Send a string
//------------------------------------------------------------------
void mRs232_SendString(char* aStrToSend)
{
	word aNbCharSent = 0;
	AS1_SendBlock((AS1_TComData*)aStrToSend, strlen(aStrToSend), &aNbCharSent);
}

//------------------------------------------------------------------
// Recieve a string
//------------------------------------------------------------------
void mRs232_RecieveString(char* aStrToRecieve, uint8_t aNbbytesToRecieve)
{
	word aNbCharSent = 0;
	AS1_RecvBlock((AS1_TComData*)aStrToRecieve, aNbbytesToRecieve, &aNbCharSent);
}

//------------------------------------------------------------------
// Clear the reception buffer
//------------------------------------------------------------------
void mRs232_ClearRxBuffer(void)
{
	AS1_ClearRxBuf();
}
