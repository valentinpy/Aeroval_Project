/*
 * AppTerminalPrint.c
 *
 *  Created on: Jun 27, 2015
 *      Author: matthieu.favrebul
 */


