/*
 * AppMeasureManager.h
 *
 *  Created on: Jun 27, 2015
 *      Author: matthieu.favrebul
 */

#ifndef APPMEASUREMANAGER_H_
#define APPMEASUREMANAGER_H_

//---------------------------------------------------
// Initialisation de l'App MeasureManager
//---------------------------------------------------
void AppMeasureManager_Init(void);

//---------------------------------------------------
// Execution de l'App MeasureManager
//---------------------------------------------------
void AppMeasureManager_Execute(void);

#endif /* APPMEASUREMANAGER_H_ */
