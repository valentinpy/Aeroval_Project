/*
 * EM7180.c
 *
 *  Created on: Mar 20, 2015
 *      Author: matthieu.favrebul
 */

#include "CI2C1.h"
#include "EM7180.h"
#include "cstring"

#define EM7180_ADDR 0x28
#define SetupValue_MagRate 0x1E
#define SetupValue_AccelRate 0x0A
#define SetupValue_GyroRate 0x14

typedef byte EM7180_DataEnum;
EM7180_DataEnum Data_enum = 0x00;

static char aOutputBuff[50];
static char aInputBuff[50];

//-------------------------------------------------------------------
// Read Register sensor, size of 1 byte
//-------------------------------------------------------------------
uint8_t EM7180_ReadUint8(EM7180_Addr_UInt8Reg_Enum aAddr)
{
	byte aErr = ERR_OK;
	word nbByteRead = 0;
	
	// Adresse du registre 
	aOutputBuff[0] = aAddr;
	// Envoi de la trame
	aErr = CI2C1_SendBlock(aOutputBuff, sizeof(uint8_t), &nbByteRead);
	if(ERR_OK != aErr);
		//printf("[ERROR]: EM7180_ReadUint8 : error = %d\n",aErr);
	
	// Lecture de 1 byte sur le bus
	aErr = CI2C1_RecvBlock(aInputBuff, sizeof(uint8_t),&nbByteRead);
	if(ERR_OK != aErr);
		//printf("[ERROR]: EM7180_ReadUint8 : error = %d\n",aErr);
	
	return (uint8_t) aInputBuff[0];
}

//-------------------------------------------------------------------
// Read Register sensor, size 2 bytes
//-------------------------------------------------------------------
uint16_t EM7180_ReadUint16(EM7180_Addr_UInt16Reg_Enum aAddr)
{
	uint16_t aRetVal = 0;
	byte aErr = ERR_OK;
	word nbByteRead = 0;
	
	// Adresse du registre
	aOutputBuff[0] = aAddr; 
	// Envoi de la trame
	aErr = CI2C1_SendBlock(aOutputBuff, sizeof(uint8_t), &nbByteRead);
	if(ERR_OK != aErr);
		//printf("[ERROR]: EM7180_ReadUint16 : error = %d\n",aErr);
	
	// Lecture de 2 bytes sur le bus
	aErr = CI2C1_RecvBlock(aInputBuff, sizeof(uint16_t),&nbByteRead);
	if(ERR_OK != aErr);
		//printf("[ERROR]: EM7180_ReadUint16 : error = %d\n",aErr);
	
	memcpy(&aRetVal, aInputBuff, sizeof(uint16_t));
	return aRetVal;
}

//-------------------------------------------------------------------
// Read Register sensor, size 4 bytes
//-------------------------------------------------------------------
uint32_t EM7180_ReadUint32(EM7180_Addr_UInt32Reg_Enum aAddr)
{
	uint32_t aRetVal = 0;
	byte aErr = ERR_OK;
	word nbByteRead = 0;
	
	// Adresse du registre
	aOutputBuff[0] = aAddr; 
	// Envoi de la trame
	aErr = CI2C1_SendBlock(aOutputBuff, sizeof(uint8_t), &nbByteRead);
	if(ERR_OK != aErr);
		//printf("[ERROR]: EM7180_ReadUint32 : error = %d\n",aErr);
	
	// Lecture de 4 bytes sur le bus
	aErr = CI2C1_RecvBlock(aInputBuff, sizeof(uint32_t),&nbByteRead);
	if(ERR_OK != aErr);
		//printf("[ERROR]: EM7180_ReadUint32 : error = %d\n",aErr);
	
	memcpy(&aRetVal, aInputBuff, sizeof(uint32_t));
	return aRetVal;
}

//-------------------------------------------------------------------
// Read All data of the sensor
//-------------------------------------------------------------------
void EM7180_ReadAllData(EM7180_DataStruct* aStructPtr)
{
	byte aErr = ERR_OK;
	word nbByteRead = 0;
	
	// Adresse du registre
	aOutputBuff[0] = QX; 
	// Envoi de la trame
	aErr = CI2C1_SendBlock(aOutputBuff, sizeof(uint8_t), &nbByteRead);
	if(ERR_OK != aErr);
		//printf("[ERROR]: EM7180_ReadAllData : error = %d\n",aErr);
	
	// Lecture de 4 bytes sur le bus
	aErr = CI2C1_RecvBlock(aInputBuff, sizeof(EM7180_DataStruct),&nbByteRead);
	if(ERR_OK != aErr);
		//printf("[ERROR]: EM7180_ReadAllData : error = %d\n",aErr);
	
	memcpy(aStructPtr, aInputBuff, sizeof(EM7180_DataStruct));
}

//-------------------------------------------------------------------
// Write Register sensor, size of 1 byte
//-------------------------------------------------------------------
void EM7180_WriteUint8(EM7180_Addr_UInt8Reg_Enum aAddr, uint8_t aData)
{
	byte aErr = ERR_OK;
	word nbByteSent = 0;
	
	// Adresse du registre
	aOutputBuff[0] = aAddr;
	// Donn�e � envoyer 
	aOutputBuff[1] = aData;
	
	//Envoi des donn�es sur le bus
	aErr = CI2C1_SendBlock(aOutputBuff, sizeof(uint16_t), &nbByteSent);
	if(ERR_OK != aErr);
		//printf("[ERROR]: EM7180_WriteUint8 : error = %d\n",aErr);
}

//-------------------------------------------------------------------
// Basic setup of the sensor
//-------------------------------------------------------------------
void EM7180_Setup(void)
{
	
	// Reset hardware du module
	EM7180_WriteUint8(ResetReq, 0x01);
	// Check EEPROM detected by SENTRAL
	while(FALSE == (0x01 & EM7180_ReadUint8(SentralStatus)));
	// Check Configuration file uploaded from EEPROM to SENTRAL
	while(FALSE == (0x01 & (EM7180_ReadUint8(SentralStatus) >> 1)));
	// Check if upload has successfull finished (CRC = OK)
	if(FALSE == (0x01 & (EM7180_ReadUint8(SentralStatus) >> 2)))
	{
		//printf("[Sentral / INFO]	Configuration file successfully uploaded!\n");
	}
	else
	{
		//printf("[Sentral / ERROR]	Failed to upload configuration file!\n");
	}
	
	// Set MagRate register to 100Hz
	EM7180_WriteUint8(MagRate, 0x64);
	// Set AccelRate register to 100Hz
	EM7180_WriteUint8(AccelRate, 0x0A);
	// Set GyroRate register to 150Hz
	EM7180_WriteUint8(GyroRate, 0x0F);
	// Set QRateDivisor to 1 (Related to GyroRate -> 150Hz / QRateDivisor)
	EM7180_WriteUint8(QRateDivisor, 0x01); // -> env 75 Hz
	//Set AlgorithmControl register (enable heading, pitch and roll)
	EM7180_WriteUint8(AlgorithmControl, 0x06);
	// Set EnableEvent register (enable quaternions interrupt)
	EM7180_WriteUint8(EnableEvents, 0x07);	
}

//-------------------------------------------------------------------
// Run sensor algorithm
//-------------------------------------------------------------------
void EM7180_Open(void)
{
	// Enable run Sentral sensor algorithm
	EM7180_WriteUint8(HostControl, 0x01);
}

//-------------------------------------------------------------------
// Stop sensor algorithm
//-------------------------------------------------------------------
void EM7180_Close(void)
{
	// Disable run Sentral sensor algorithm
	EM7180_WriteUint8(HostControl, 0x00);
}


