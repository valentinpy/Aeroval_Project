/*
 * BT_HC_0305.h
 *
 *  Created on: Jun 29, 2015
 *      Author: matthieu.favrebul
 */

#ifndef BT_HC_0305_H_
#define BT_HC_0305_H_

//------------------------------------------------
// Initialisation du bluetooth avec les commandes AT
//------------------------------------------------
void BT_HC_0305_Setup(void);

#endif /* BT_HC_0305_H_ */
