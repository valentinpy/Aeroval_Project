/* ###################################################################
**     Filename    : main.c
**     Project     : Smartstick_quaternions_demonstrator
**     Processor   : MKL25Z128VLK4
**     Version     : Driver 01.01
**     Compiler    : GNU C Compiler
**     Date/Time   : 2015-03-12, 18:24, # CodeGen: 0
**     Abstract    :
**         Main module.
**         This module contains user's application code.
**     Settings    :
**     Contents    :
**         No public methods
**
** ###################################################################*/
/*!
** @file main.c
** @version 01.01
** @brief
**         Main module.
**         This module contains user's application code.
*/         
/*!
**  @addtogroup main_module main module documentation
**  @{
*/         
/* MODULE main */


/* Including needed modules to compile this module/procedure */
#include "Cpu.h"
#include "Events.h"
#include "Bit1.h"
#include "Bit2.h"
#include "Bit3.h"
#include "CI2C1.h"
#include "IntI2cLdd1.h"
#include "InterruptSentral.h"
#include "ExtIntLdd1.h"
#include "InterruptButton1.h"
#include "ExtIntLdd3.h"
#include "InterruptButton2.h"
#include "ExtIntLdd2.h"
#include "AT_Mode_BT_n.h"
#include "AS1.h"
#include "ASerialLdd1.h"
#include "FC321.h"
#include "RealTimeLdd1.h"
#include "TU2.h"
#include "Reset_BT_n.h"
/* Including shared modules, which are used for whole project */
#include "PE_Types.h"
#include "PE_Error.h"
#include "PE_Const.h"
#include "IO_Map.h"
#include "mRs232.h"
#include "BT_HC_0305.h"

#include "EM7180.h"
#include "AppMbox.h"
#include "AppMeasureManager.h"
#include "Timer.h"

#include "stdio.h"

/* User includes (#include below this line is not maintained by Processor Expert) */


/*lint -save  -e970 Disable MISRA rule (6.3) checking. */
int main(void)
/*lint -restore Enable MISRA rule (6.3) checking. */
{
  /* Write your local variable definition here */

  /*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
  PE_low_level_init();
  /*** End of Processor Expert internal initialization.                    ***/

  /* Write your code here */
  /* For example: for(;;) { } */
  
  //-------------------------------------------------------------------------------------------
  //-------------------------------------------------------------------------------------------
  bool executeFlag = FALSE;
  uint32 aVal = 0;
  char aBuff[256] = {0};

  BT_HC_0305_Setup();  
  EM7180_Setup();
  EM7180_Open();
  

  for(;;)
  {
	  
	  // Si le bouton1 est press�
	  if(TRUE == AppMbox_Interrupt.Button1)
	  {
		  // Reset du flag
		  AppMbox_Interrupt.Button1 = FALSE;
		  // On met un flag � un et on envoie des donn�es
		  if(FALSE == executeFlag)
		  {
			  Bit1_ClrVal(Bit1_DeviceData);
			  executeFlag = TRUE;
		  }
		  // On met un flag � z�ro et on arrette d'envoyer des donn�es
		  else
		  {
			  Bit1_SetVal(Bit1_DeviceData);
			  executeFlag = FALSE;
		  }
			  
	  }
	  
	  if(TRUE == executeFlag)
	  {
		  // Si interruption, on lit le registre de status
		  if(TRUE == AppMbox_Interrupt.SentralFlag)
		  {
			  //Reset du flag
			  AppMbox_Interrupt.SentralFlag = FALSE;
			  // Lecture registre status, reset de l'interruption
			  EM7180_ReadUint8(EventStatus);
			  // Lecture des donn�es
			  EM7180_ReadAllData(&AppMbox_MeasureManager.AllSENTralDataStruct);
			  // Print des valeurs
			  sprintf(aBuff,"%f,%f,%f,%f,%u,%d,%d,%d,%u,%d,%d,%d,%u,%d,%d,%d,%u\r\n",	AppMbox_MeasureManager.AllSENTralDataStruct.QX,
																						AppMbox_MeasureManager.AllSENTralDataStruct.QY,
																						AppMbox_MeasureManager.AllSENTralDataStruct.QZ,
																						AppMbox_MeasureManager.AllSENTralDataStruct.QW,
																						AppMbox_MeasureManager.AllSENTralDataStruct.QTime,
																						AppMbox_MeasureManager.AllSENTralDataStruct.MX,
																						AppMbox_MeasureManager.AllSENTralDataStruct.MY,
																						AppMbox_MeasureManager.AllSENTralDataStruct.MZ,
																						AppMbox_MeasureManager.AllSENTralDataStruct.MTime,
																						AppMbox_MeasureManager.AllSENTralDataStruct.AX,
																						AppMbox_MeasureManager.AllSENTralDataStruct.AY,
																						AppMbox_MeasureManager.AllSENTralDataStruct.AZ,
																						AppMbox_MeasureManager.AllSENTralDataStruct.ATime,
																						AppMbox_MeasureManager.AllSENTralDataStruct.GX,
																						AppMbox_MeasureManager.AllSENTralDataStruct.GY,
																						AppMbox_MeasureManager.AllSENTralDataStruct.GZ,
																						AppMbox_MeasureManager.AllSENTralDataStruct.GTime);
			  mRs232_SendString(aBuff);
		  }
	  }
  }
    
  //-------------------------------------------------------------------------------------------
  //-------------------------------------------------------------------------------------------
  
  /*** Don't write any code pass this line, or it will be deleted during code generation. ***/
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;){}
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/

/* END main */
/*!
** @}
*/
/*
** ###################################################################
**
**     This file was created by Processor Expert 10.3 [05.09]
**     for the Freescale Kinetis series of microcontrollers.
**
** ###################################################################
*/
