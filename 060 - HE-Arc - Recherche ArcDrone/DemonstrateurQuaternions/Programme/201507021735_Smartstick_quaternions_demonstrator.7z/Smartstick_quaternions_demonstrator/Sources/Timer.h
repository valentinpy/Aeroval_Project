/*
 * Timer.h
 *
 *  Created on: Jun 30, 2015
 *      Author: matthieu.favrebul
 */

#ifndef TIMER_H_
#define TIMER_H_

#include "PE_Types.h"

typedef enum{
 kWait1000ms = 1000,
 kWait500ms = 500,
 kWait200ms = 200,
 kWait100ms = 100,
 kWait10ms = 10,
 kWait1ms = 1
}WaitTimer_Enum;

//--------------------------------------------------
// Timer blocant
//--------------------------------------------------
void Timer_LockedWait(WaitTimer_Enum aTimeToWait);

#endif /* TIMER_H_ */
