/*
 * AppMbox.c
 *
 *  Created on: Jun 27, 2015
 *      Author: matthieu.favrebul
 */
#include "AppMbox.h"


//-------------------------------------------------
// On cr�e chaque structure de donn�es
//-------------------------------------------------
AppMbox_Interrupt_Struct 			AppMbox_Interrupt;
AppMbox_MeasureManager_Struct		AppMbox_MeasureManager;
