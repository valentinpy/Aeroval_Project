/*
 * BT_HC_0305.c
 *
 *  Created on: Jun 29, 2015
 *      Author: matthieu.favrebul
 */

#include <stdio.h>
#include "string.h"
#include "AT_Mode_BT_n.h"
#include "mRs232.h"
#include "FC321.h"

#include "Timer.h"
#include "AS1.h"
#include "Reset_BT_n.h"

//------------------------------------------------
// Initialisation du bluetooth avec les commandes AT
//------------------------------------------------
void BT_HC_0305_Setup(void)
{
	char aTempBuffer[50] = {0};

	// On set le baudrate de l'UART � 38400
	AS1_SetBaudRateMode(AS1_BM_38400BAUD);
	
	// Module bluetooth: mise en mode AT commande
	//-------------------------------------------
	// Reset du module bluetooth
	Reset_BT_n_ClrVal(Reset_BT_n_DeviceData);
	// Set du mode AT commande
	AT_Mode_BT_n_SetVal(AT_Mode_BT_n_DeviceData);
	// Attente d'une seconde
	Timer_LockedWait(kWait1000ms);
	// On enl�ve le reset du bluetooth
	Reset_BT_n_SetVal(Reset_BT_n_DeviceData);
	// Attente d'une seconde
	Timer_LockedWait(kWait1000ms);
	
	// Module bluetooth: R�glage du baudrate
	//------------------------------------------
	// Clear du buffer de r�ception
	mRs232_ClearRxBuffer();
	// Reglage du bluetooth
	mRs232_SendString("AT+UART=460800,0,0\r\n");
	// Attente d'une seconde pour la r�ponse
	Timer_LockedWait(kWait1000ms);
	// On va lire dans le buffer la r�ponse
	mRs232_RecieveString(aTempBuffer, 20);
	
	// Reset du module bluetooth
	Reset_BT_n_ClrVal(Reset_BT_n_DeviceData);
	// Set du mode communication
	AT_Mode_BT_n_ClrVal(AT_Mode_BT_n_DeviceData);
	// Attente d'une seconde pour la r�ponse
	Timer_LockedWait(kWait1000ms);
	// On enl�ve le reset du bluetooth
	Reset_BT_n_SetVal(Reset_BT_n_DeviceData);
	
	// On set le baudrate de l'UART � 460800
	AS1_SetBaudRateMode(AS1_BM_460800BAUD);
	
//	// Print si il y a une erreur dans la proc�dure
//	if(0 != strcmp(aTempBuffer,"OK\r\n"))
//		mRs232_SendString("[ERROR]: BT_HC_0305_Setup\r\n");
}
