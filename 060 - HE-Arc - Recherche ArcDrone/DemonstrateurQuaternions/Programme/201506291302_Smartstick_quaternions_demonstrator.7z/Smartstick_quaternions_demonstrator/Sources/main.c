/* ###################################################################
**     Filename    : main.c
**     Project     : Smartstick_quaternions_demonstrator
**     Processor   : MKL25Z128VLK4
**     Version     : Driver 01.01
**     Compiler    : GNU C Compiler
**     Date/Time   : 2015-03-12, 18:24, # CodeGen: 0
**     Abstract    :
**         Main module.
**         This module contains user's application code.
**     Settings    :
**     Contents    :
**         No public methods
**
** ###################################################################*/
/*!
** @file main.c
** @version 01.01
** @brief
**         Main module.
**         This module contains user's application code.
*/         
/*!
**  @addtogroup main_module main module documentation
**  @{
*/         
/* MODULE main */


/* Including needed modules to compile this module/procedure */
#include "Cpu.h"
#include "Events.h"
#include "Bit1.h"
#include "Bit2.h"
#include "Bit3.h"
#include "CI2C1.h"
#include "IntI2cLdd1.h"
#include "CsIO1.h"
#include "IO1.h"
#include "InterruptSentral.h"
#include "ExtIntLdd1.h"
#include "InterruptButton.h"
#include "ExtIntLdd2.h"
#include "TU1.h"
/* Including shared modules, which are used for whole project */
#include "PE_Types.h"
#include "PE_Error.h"
#include "PE_Const.h"
#include "IO_Map.h"

#include "EM7180.h"
#include "AppMbox.h"
#include "AppMeasureManager.h"

/* User includes (#include below this line is not maintained by Processor Expert) */


/*lint -save  -e970 Disable MISRA rule (6.3) checking. */
int main(void)
/*lint -restore Enable MISRA rule (6.3) checking. */
{
  /* Write your local variable definition here */

  /*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
  PE_low_level_init();
  /*** End of Processor Expert internal initialization.                    ***/

  /* Write your code here */
  /* For example: for(;;) { } */
  
  //-------------------------------------------------------------------------------------------
  //-------------------------------------------------------------------------------------------
  int i;
  
  char aReadValues[50] = {0};
//  word nbCharToSend = 2;
  word aErr = 0;
  char aStatus;
//  
  EM7180_Setup();
  EM7180_Open();
  
  AppMeasureManager_Init();
  
  for(;;)
  {
	  
	  if(TRUE == AppMbox_Interrupt.Button)
	  {
			  printf("Boutton Press�!!!\n");
			  AppMbox_Interrupt.Button = FALSE;
	  }
	  
	  AppMeasureManager_Execute();
	  
//	  if(TRUE == AppMbox_Interrupt.SentralFlag)
//	  	  {
//	  			  printf("SentralInterrupt !!!\n");
//	  			  AppMbox_Interrupt.SentralFlag = FALSE;
//	  	  }
//	  EM7180_WriteUint8(ResetReq, 0x01);
//	  EM7180_WriteUint8(HostControl, 0x01);
//	  
	  
//	  aReadValues[0] = EM7180_ReadUint8(EventStatus);
//	  aReadValues[1] = EM7180_ReadUint8(EventStatus);
//	  aReadValues[2] = EM7180_ReadUint8(Product_ID);
//	  aReadValues[3] = EM7180_ReadUint8(SentralStatus);
//	  aReadValues[4] = EM7180_ReadUint8(AlgorithmStatus);
//	  aReadValues[5] = EM7180_ReadUint8(EnableEvents);
//	  aReadValues[6] = EM7180_ReadUint8(EnableEvents);
//	  aReadValues[7] = EM7180_ReadUint8(MagRate);
//	  aReadValues[8] = EM7180_ReadUint8(AccelRate);
//	  aReadValues[9] = EM7180_ReadUint8(GyroRate);
	  
	  //EM7180_WriteUint8(HostControl, 0x00);
	  
	  
//	  Bit1_ClrVal(Bit1_DeviceData);
//  	  Bit2_ClrVal(Bit2_DeviceData);
//  	  Bit3_ClrVal(Bit3_DeviceData);
  }
    
  //-------------------------------------------------------------------------------------------
  //-------------------------------------------------------------------------------------------
  
  /*** Don't write any code pass this line, or it will be deleted during code generation. ***/
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;){}
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/

/* END main */
/*!
** @}
*/
/*
** ###################################################################
**
**     This file was created by Processor Expert 10.3 [05.09]
**     for the Freescale Kinetis series of microcontrollers.
**
** ###################################################################
*/
