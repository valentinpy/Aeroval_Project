/*
 * AppMbox.h
 *
 *  Created on: Jun 27, 2015
 *      Author: matthieu.favrebul
 */

#include "PE_Types.h"
#include "EM7180.h"

#ifndef APPMBOX_H_
#define APPMBOX_H_

//-------------------------------------------------
// AppMbox est une "mail box qui permet d'�changer
// des donn�es ou des flags entre les diff�rentes
// applications. Chaque application poss�de sa
// structure de donn�es qui est cr�� dans AppMbox.c.
// Chaque structure est export�e, elle est donc
// accessible en global, par tous les fichiers.
//-------------------------------------------------


//-------------------------------------------------
// Structure de donn�es pour les interruptions
//-------------------------------------------------
typedef struct{
	// Flag de l'interruption du capteur SENTral
	bool SentralFlag;
	// Donn�es du registre eventstatus de SENTral
	uint8 SentralEventStatusReg;
	
	// Flag d'interruption du bouton poussoir
	bool Button;
}AppMbox_Interrupt_Struct;

//-------------------------------------------------
// Structure de donn�es pour AppMeasureManager
//-------------------------------------------------
typedef struct{
	// Flag = TRUE lorsque de nouvelles mesures sont disponibles
	bool NewMeasurePosted;
	// Structure de donn�es
	EM7180_DataStruct AllSENTralDataStruct;
}AppMbox_MeasureManager_Struct;


//-------------------------------------------------
// On exporte toutes les structures de donn�es pour
// les rendre accessibles depuis l'ext�rieur
//-------------------------------------------------
extern AppMbox_Interrupt_Struct 			AppMbox_Interrupt;
extern AppMbox_MeasureManager_Struct		AppMbox_MeasureManager;


#endif /* APPMBOX_H_ */
