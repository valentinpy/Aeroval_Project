/*
 * AppMeasureManager.c
 *
 *  Created on: Jun 27, 2015
 *      Author: matthieu.favrebul
 */


//---------------------------------------------------
// Machine d'�tat lecture du capteur EM7180
// 		- G�re les erreurs
//		- Lit toutes les valeurs du capteurs
//		- Met un flag � un lorsque de nouvelles valeurs sont disponibles dans la structure de donn�es
//---------------------------------------------------

#include "AppMeasureManager.h"
#include "AppMbox.h"
#include <stdio.h>

typedef enum{
	kWaitInterruptState,
	kHandleErrorStatus,
	kInitializeSentralStatus,
	kReadValuesSENTral
}MeasureManager_StateMachine_Var;

static MeasureManager_StateMachine_Var MeasureManagerState;

//---------------------------------------------------
// Initialisation de l'App MeasureManager
//---------------------------------------------------
void AppMeasureManager_Init(void)
{
	MeasureManagerState = kWaitInterruptState;
}

//---------------------------------------------------
// Execution de l'App MeasureManager
//---------------------------------------------------
void AppMeasureManager_Execute(void)
{
	printf("MeasureManagerState = %d\n", MeasureManagerState);
	
	switch(MeasureManagerState)
	{
	// On attend de nouvelles donn�es de la part du capteur EM7180
	case kWaitInterruptState:
		if(TRUE == AppMbox_Interrupt.SentralFlag)
		{
			AppMbox_Interrupt.SentralEventStatusReg = EM7180_ReadUint8(EventStatus);
			MeasureManagerState = kHandleErrorStatus;		// On passe dans l'�tat suivant de la machine
			AppMbox_Interrupt.SentralFlag = FALSE;			// On reset le flag de SENTral
		}
		break;
	// Si le flag d'erreur est � un, on print un messsage d'erreur
	case kHandleErrorStatus:
		if(TRUE == (0x01 & (AppMbox_Interrupt.SentralEventStatusReg >> 1)))
		{
			printf("[ERROR]: MeasureManager_Execute/kHandleErrorStatus : EventStatus register error bit = 1");
		} else
		{
			MeasureManagerState = kInitializeSentralStatus;	// On passe dans l'�tat suivant de la machine
		}
		break;
	// Si le flag de reset du CPU est � un, on print un message d'erreur
	case kInitializeSentralStatus:
		if(TRUE == (0x01 & (AppMbox_Interrupt.SentralEventStatusReg >> 1)))
		{
			printf("[ERROR]: MeasureManager_Execute/kInitializeSentralStatus : EventStatus register CPUreset bit = 1");
		} else
		{
			MeasureManagerState = kReadValuesSENTral;		// On passe dans l'�tat suivant de la machine
		}
		break;
	// On lit toutes les valeur du capteur EM7180
	case kReadValuesSENTral:
		EM7180_ReadAllData(&AppMbox_MeasureManager.AllSENTralDataStruct);
		MeasureManagerState = kWaitInterruptState;			// On passe dans l'�tat suivant de la machine
		break;
	}
	
	
}
