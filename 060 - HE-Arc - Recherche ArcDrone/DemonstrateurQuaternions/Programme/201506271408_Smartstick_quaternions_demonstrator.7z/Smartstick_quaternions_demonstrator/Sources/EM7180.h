/*
 * EM7180.h
 *
 *  Created on: Mar 20, 2015
 *      Author: matthieu.favrebul
 */

#ifndef EM7180_H_
#define EM7180_H_

#include "PE_Error.h"

typedef enum{
	SentralStatus	= 0x37,
	ResetReq		= 0x9B,
	HostControl		= 0x34,
	MagRate			= 0x55,
	AccelRate		= 0x56,
	GyroRate		= 0x57,
	ActualMagRate	= 0x45,
	ActualAccelRate	= 0x46,
	ActualGyroRate	= 0x47,
	QRateDivisor	= 0x32,
	EnableEvents	= 0x33,
	EventStatus		= 0x35,
	AlgorithmControl= 0x54,
	AlgorithmStatus	= 0x38,
	PassThroughControl= 0xA0,
	PassThroughStatus= 0x9E,
	Product_ID		= 0x90,
	Revision_ID		= 0x91
} EM7180_Addr_UInt8Reg_Enum;

typedef enum{
	ROM_Version		= 0x70,
	RAM_Version		= 0x72,
	QTime			= 0x10,
	MX				= 0x12,
	MY				= 0x14,
	MZ				= 0x16,
	MTime			= 0x18,
	AX				= 0x1A,
	AY				= 0x1C,
	AZ				= 0x1E,
	ATime			= 0x20,
	GX				= 0x22,
	GY				= 0x24,
	GZ				= 0x26,
	GTime			= 0x28
} EM7180_Addr_UInt16Reg_Enum;

typedef enum{
	QX				= 0x00,
	QY				= 0x04,
	QZ				= 0x08,
	QW				= 0x0C
} EM7180_Addr_UInt32Reg_Enum;

//-------------------------------------------------------------------
// Read Register capteur size of 1 byte
//-------------------------------------------------------------------
uint8_t EM7180_ReadUint8(EM7180_Addr_UInt8Reg_Enum aAddr);

//-------------------------------------------------------------------
// Read Register sensor, size 2 bytes
//-------------------------------------------------------------------
uint16_t EM7180_ReadUint16(EM7180_Addr_UInt16Reg_Enum aAddr);

//-------------------------------------------------------------------
// Read Register sensor, size 4 bytes
//-------------------------------------------------------------------
uint32_t EM7180_ReadUint32(EM7180_Addr_UInt32Reg_Enum aAddr);

//-------------------------------------------------------------------
// Write Register sensor, size of 1 byte
//-------------------------------------------------------------------
void EM7180_WriteUint8(EM7180_Addr_UInt8Reg_Enum aAddr, uint8_t aData);

// Basic setup of the sensor
//-------------------------------------------------------------------
void EM7180_Setup(void);



#endif /* EM7180_H_ */
