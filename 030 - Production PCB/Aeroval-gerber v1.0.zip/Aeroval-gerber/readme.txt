Nom du PCB:				Aeroval
Nombre de PCB: 			>=3 (Composants QFN commandés 3x)
Couches: 				6
Taille:					100 x 100mm
Diamètre percage min: 	0.25mm
Clearance:				0.15mm
Width min:				0.2mm
Sérigraphie:			top

Clearance de 0.15mm à cause des QFN (distance entre les pads)


Couches:
Top overlay
Top solder
Top layer
dielectric
Internal plane (GND)
dielectric
Signal (VERT)
dielectric
Signal (HOR)
dielectric
Internal plane (PWR)
dielectric
Bottom layer
Bottom solder
